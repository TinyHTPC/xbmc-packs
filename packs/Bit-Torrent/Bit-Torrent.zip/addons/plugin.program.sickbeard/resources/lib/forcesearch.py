import sickbeard

Sickbeard = sickbeard.SB()

Sickbeard.ForceSearch()
