"""Common data-modeling Python types

The idea of the basictypes package is to provide
types which provide enough metadata to allow an
application to use introspection to perform much
of the housekeeping required to create business
applications.
"""
