from .main import Release


def autoload():
    return Release()
