from .main import Search


def autoload():
    return Search()
