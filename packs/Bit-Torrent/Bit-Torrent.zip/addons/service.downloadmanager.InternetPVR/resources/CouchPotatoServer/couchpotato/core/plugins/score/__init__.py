from .main import Score


def autoload():
    return Score()
