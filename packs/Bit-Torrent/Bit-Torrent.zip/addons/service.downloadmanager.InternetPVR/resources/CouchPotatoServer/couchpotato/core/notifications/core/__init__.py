from .main import CoreNotifier


def autoload():
    return CoreNotifier()
