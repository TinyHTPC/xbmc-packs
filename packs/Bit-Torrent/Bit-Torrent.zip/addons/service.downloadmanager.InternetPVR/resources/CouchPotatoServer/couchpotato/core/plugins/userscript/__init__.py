from .main import Userscript


def autoload():
    return Userscript()
