from .main import CouchPotatoApi


def start():
    return CouchPotatoApi()

config = []
