from .main import CategoryPlugin


def start():
    return CategoryPlugin()

config = []
