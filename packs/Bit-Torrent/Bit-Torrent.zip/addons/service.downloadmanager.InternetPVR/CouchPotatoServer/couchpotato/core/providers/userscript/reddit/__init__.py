from .main import Reddit


def start():
    return Reddit()

config = []
