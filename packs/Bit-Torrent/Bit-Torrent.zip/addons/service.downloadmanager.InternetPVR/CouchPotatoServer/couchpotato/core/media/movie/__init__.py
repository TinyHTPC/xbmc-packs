from couchpotato.core.media import MediaBase


class MovieTypeBase(MediaBase):

    _type = 'movie'
