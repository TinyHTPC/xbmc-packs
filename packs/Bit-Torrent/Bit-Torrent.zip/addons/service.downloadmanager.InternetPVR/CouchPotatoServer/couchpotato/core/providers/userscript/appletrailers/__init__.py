from .main import AppleTrailers


def start():
    return AppleTrailers()

config = []
