from .main import Criticker


def start():
    return Criticker()

config = []
