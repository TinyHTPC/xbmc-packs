from .main import ProfilePlugin


def start():
    return ProfilePlugin()

config = []
