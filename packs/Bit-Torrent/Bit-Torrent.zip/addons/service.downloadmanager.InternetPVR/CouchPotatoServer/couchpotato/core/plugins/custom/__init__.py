from .main import Custom


def start():
    return Custom()

config = []
