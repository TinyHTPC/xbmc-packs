from .main import Userscript


def start():
    return Userscript()

config = []
