from .main import MovieLibraryPlugin


def start():
    return MovieLibraryPlugin()

config = []
