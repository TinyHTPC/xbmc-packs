from .main import MoviesIO


def start():
    return MoviesIO()

config = []
