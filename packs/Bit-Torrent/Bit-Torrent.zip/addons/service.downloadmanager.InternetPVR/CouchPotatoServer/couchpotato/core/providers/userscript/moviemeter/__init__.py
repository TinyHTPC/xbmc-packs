from .main import MovieMeter


def start():
    return MovieMeter()

config = []
