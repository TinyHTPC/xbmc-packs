from .main import QualityPlugin


def start():
    return QualityPlugin()

config = []
