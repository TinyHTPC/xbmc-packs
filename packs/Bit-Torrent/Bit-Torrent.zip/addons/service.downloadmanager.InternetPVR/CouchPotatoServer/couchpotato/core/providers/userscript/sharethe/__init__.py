from .main import ShareThe


def start():
    return ShareThe()

config = []
