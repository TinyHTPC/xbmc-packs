from .main import Release


def start():
    return Release()

config = []
