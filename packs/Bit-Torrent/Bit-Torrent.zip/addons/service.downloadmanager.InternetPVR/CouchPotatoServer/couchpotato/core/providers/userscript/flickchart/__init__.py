from .main import Flickchart


def start():
    return Flickchart()

config = []
